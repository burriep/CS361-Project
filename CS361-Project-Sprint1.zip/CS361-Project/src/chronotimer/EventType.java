package chronotimer;

public enum EventType {
	IND, PARIND, GRP, PARGRP;
}
