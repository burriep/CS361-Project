package chronotimer;

public enum SensorType {
	EYE, PAD, PUSH, GATE;
}
