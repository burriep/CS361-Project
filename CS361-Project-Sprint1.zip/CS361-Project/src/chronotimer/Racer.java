package chronotimer;

public class Racer {
	private int id;

	public Racer(int n) {
		id = n;
	}

	public int getNumber() {
		return id;
	}

	public String toString() {
		return "" + id;
	}
}
